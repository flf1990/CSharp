﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms天气预报
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Weather.WeatherWebServiceSoapClient w = new Weather.WeatherWebServiceSoapClient("WeatherWebServiceSoap");
            cn.com.webxml.www.WeatherWebService w = new cn.com.webxml.www.WeatherWebService();
            string[] s = new string[23];
            string city = this.textBox1.Text.Trim();
            s = w.getWeatherbyCityName(city);
            if (s[8] == "")
            {
                MessageBox.Show("暂不支持你查询的城市！");
            }
            else
            {
                //pictureBox1.Image = Image.FromFile(@"d:\image\" + s[8] + "");
                this.label1.Text = s[1] + " " + s[6];
                textBox2.Text = s[10];
            }  
        }
    }
}
